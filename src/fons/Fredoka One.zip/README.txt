Fredoka One is a big, round, bold font that is perfect for adding a little fun to any headline or large text.

To contribute to the project contact [Milena Brandao](mailto:milenabbrandao@gmail.com).